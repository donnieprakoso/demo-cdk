def handler(event, context):
    print("Hello World from AWS CDK!")
